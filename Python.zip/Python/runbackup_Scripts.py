import time
from subprocess import run
from datetime import datetime

def run_script():
    current_time = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
    filename = "csp/mysql/my_sql_{}.sql".format(current_time)

    run(["python", "scripts/back_up_Scripts.py", filename])  


while True:
    run_script()
    time.sleep(120) 
