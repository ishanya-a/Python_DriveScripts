# import json
# import os
# import requests
# from datetime import datetime

# service_account_key_path = "path/to/your/service_account_key.json"

# headers = {"Authorization": "Bearer ya29.a0AfB_byANgmrfdfOg5WxcRJ7mdbRWqBWqhKwpbhlgv1EQ4VIdNqXdYOQbmTm3AhP3nuYwA8NtOajWOI2wP8MwXRC7RZKruyt9DSCXP0O3ARGEP1meFDdzouJaJrqxlBWdwBaZthDGMyRpRrS0MDDAnAyN6IXh6-2YCw66aCgYKAbESARASFQHGX2Mi3cPkODKcVOxTtyidrvaf9A0171"}

# current_time = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
# filename = f"csp_mysql_{current_time}.sql"
# source_file = "csp.sql"

# if not os.path.exists(source_file):
#     with open(source_file, "w") as file:
#         pass

# para = {
#     "name": filename,
#     "parents": ["1bXG3vNvtDrDGkcxc5dbVSUwh3qNF3plO"]
# }
# files = {
#     'data': ('metadata', json.dumps(para), 'application/json; charset= UTF-8'),
#     'file': (filename, open(source_file, "rb"))
# }
# r = requests.post(
#     "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
#     headers=headers,
#     files=files
# )
# print(r.text)

from googleapiclient.discovery import build
from google.oauth2 import service_account
from googleapiclient.http import MediaFileUpload
from datetime import datetime
import os

SERVICE_ACCOUNT_INFO = {
  "type": "service_account",
  "project_id": "superb-gear-405706",
  "private_key_id": "08c62fbc00c96b911a183733938ee0634dc4e550",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQChtAewbvFCW5JQ\n/ZVcxBClJMPuAIdk27C+AAGQi5TeF7wnqs0jz5sqCqa5oI3+8xWavLeBf76Q9yyB\nWcB4oSCvmi9VsVMAIOYZkuuWEDqVRuWajGRd/pfxDMwmaaQuOIom9NDz7cE9e0wL\nkZM3WWjMOr8593ad9Pf8D9xN4x7QDkD8AVP1qOLCZufbU/WJeVzmbfXCkdZS4Gg1\nwW+E5rgxUFnGRgRM2Yaf7KRS5Z+edUlpIALAgUW2fnIa/8nF1ibqN0wUYtizM0rw\nADcDW2wigjdfqexoygWyJW3gcVwonsl/o0Dy/Bga1T4YFxTiJ6hu3AZcJXIHyi6X\n+q5ZHMCVAgMBAAECggEACGL07yKh4qYrLYYpY/lLP7VrcAGZBBMc1I3dhuimXOpw\nOMJ0B0JyMrkAsqnwE2P6H99fyRieApi/Nyo3gEojDth5UgFzY5NRO8xR6aOH1kwq\nBlz3q6RTrw3R3MAn4rnN+H1EBRK0rgKiDAuNzhYWCFmXp2L9RO36mpkb/PIlm/a8\nINjIeNqXobdbiORXnDTQWcK+BI1ACu4mhP3frxyZ8JhfDmtdgL4MJxaOuLuqmR7W\nqg6mM9XM/t4Bl2ix2OD2WcguaNgAj4HwzvpPj1gn4MG6JzqOSTLDoX6GLk3ZCaBa\nu608I32kBynrf/XmRpFXQIg1xOnnXYh9sAk61lzmlQKBgQDa4IONCgpwyUMwZXkr\njVA20JySpFz28PaAg/2LiYkKSEUfjXoeDJ3Txxal58IWNgGWYDZkkx5EjG5WZVe5\n+RKXh17OT4KprdZgRcf5DPVNi3jFTsQ+9hJO4qAS1wnr9fjA1jTse579tsDbY9Kl\nYvoCY5Fpg4adPzo56JbsnxyxtwKBgQC9IRJG1bJxWPFPp9+42M4zOOiGpScyEO8k\nsJsX84L0/nxNq1IebcISHKRzNlAZWnxNNw7N93XFY2DjV31WjdBYucu/l/TKNZpZ\n1n8mQ4tPGapAqW892RGUS9s9mdvGs1Wk8NVNGx4syGeiqByAB/tGjXp9uzJHiFQQ\nD3/b96DwEwKBgCL8uIqXDEwzH9ZgohngIO5iMmUOeP3QTtcEQkdH2OwX2VTN3LNo\n+OGddXVXsqKyR1auUoOJMNFsUUbmNDu6IMqwDOuVsiFFdHs3LFwXQi7/GHMRwDUA\nSLTrbQMV9LQPQZAxrYwPxr5vtCxdrJJbW/N9zwS6zY3dSYVwNI/mb0PJAoGAB9o0\nqQ48T2py8my05DbUMNo/BUAcJX8AftR6S/9HQ6bBQHRJf4vtD9Vymnn5z2OrX4VW\nrwSENkLPBgFe6dYPfW+RXw4PEsow82PteYg6Y3lcUTz3qmi1yyNvIdqeflx5xNRe\n9smWciOL8fvq2wH5088R8+Bu0Pt/Cf+qvlZEr1MCgYA/TANJCVFxnZtsXKXyljSC\naT01x2IMjD7HvliPH18j9JSJskI6sa92HKyIzxI2TuIGszWfVITiRTZS2bvryvP4\nrUaC+kqfanqtJU/wzrr5Bzs3y7wrLuRHl0TA4Smosy5Mofnf2vOn8sXFERINHjfO\nljFwwv7DrqelC7Wt2I8qxA==\n-----END PRIVATE KEY-----\n",
  "client_email": "backup-files@superb-gear-405706.iam.gserviceaccount.com",
  "client_id": "103064054140793303310",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/backup-files%40superb-gear-405706.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
}

SCOPES = ['https://www.googleapis.com/auth/drive']
PARENT_FOLDER_ID = "1CJN_uDv3MGU1U37TG9JeD3P_QHEPHxHL"

def authenticate():
    creds = service_account.Credentials.from_service_account_info(SERVICE_ACCOUNT_INFO, scopes=SCOPES)
    return creds

def upload_photo(file_name):
    if not os.path.exists(file_name):
        with open(file_name,'w') as f:
            pass
    creds = authenticate()
    service = build('drive', 'v3', credentials=creds)

    current_time = datetime.now().strftime("%Y-%m-%d-%H:%M:%S")
    Filename = f"csp-mysql-{current_time}.sql"

    file_metadata = {
        'name': Filename,
        'parents': [PARENT_FOLDER_ID]
    }

    media = MediaFileUpload(file_name, resumable=True)

    file = service.files().create(
        body=file_metadata,
        media_body=media
    ).execute()

file="csp.sql"
upload_photo(file)

