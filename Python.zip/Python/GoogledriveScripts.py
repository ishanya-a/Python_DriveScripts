import os
import google.auth
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaFileUpload
from google.oauth2 import service_account
from datetime import datetime

def upload_file():
    try:
        cred = service_account.Credentials.from_service_account_file(
            "service-account-key.json",
            scopes=["https://www.googleapis.com/auth/drive"]
        )

        service = build("drive", "v3", credentials=cred)
        
        filename = "csp.sql"
        folder_id = "1CJN_uDv3MGU1U37TG9JeD3P_QHEPHxHL"

        if not os.path.exists(filename):
            with open(filename, 'w') as f:
                pass
        current_time = datetime.now().strftime("%Y-%m-%d-%H:%M:%S")
        file_save_as = f"csp-mysql-{current_time}.sql"
        response = service.files().list(
            q=f"name='{file_save_as}' and parents='{folder_id}'",
            spaces='drive',
            fields='nextPageToken, files(id, name)',
            pageToken=None
        ).execute()

        file_metadata = {
            "name": file_save_as,
            "parents": [folder_id]
        }
        media = MediaFileUpload(filename, mimetype="text/plain")

        file = (
            service.files()
            .create(body=file_metadata, media_body=media, fields="id")
            .execute()
        )
        print(f"New File '{file_save_as}' Created in Google Drive - File ID: {file.get('id')}")
    except HttpError as error:
        print(f"An error occurred: {error}")
        file = None

    return file.get("id") if file else None

if __name__ == "__main__":
    upload_file()
